# HiveMind JS-BotNet
A Simple JS and PHP Botnet, written by a very nice person.

*For Educational Use Only*




# Instructions
1. Download Repo and upload it to your control server.

2. Copy bot.js and figure out a way to display it on
the webpage of your choosing. 
*Only do this with webistes you actually own*

3. Done, you can edit cmds.php with php commands of your choice, these will be run in a hidden iframe on
the target site. Also, update miner.html with your coinhive Site key so you can also make money off of the 
Botnet. For added security I would recomend using a Javascript Obfuscator
https://javascriptobfuscator.com/Javascript-Obfuscator.aspx

# Usage
Can be used to conduct a DDoS Attack, it can be also used to mine Monero and preform calculations.
For voluntary participants have them upload node.js to their website. Then anyone running that JavaScript file will be a willing 
participant in your botnet. If you navigate to /BotNet/CC/KeyLogger you can set up an experimental in-browser keylogger.

*It has been proven possible to run javascript in ads so thats an idea to think about :)*



*I am not responsible for any perceived damages or harm that may come from misuse of this software*
