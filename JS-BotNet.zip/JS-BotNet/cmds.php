<?php
echo '<script>alert("This is an example Command in cmds.php");</script>';
            
            
 
            
?>
