# Embedded file name: core\header.py
from core import config

def Banner():
    print '\n\n   +--------------------------------------------------------MUDDY C3-\n   :". /  /  /\n   :.-". /  /\n   : _.-". /\n   :"  _.-".\n   :-""     ".\n   :\n   :\n ^.-.^\n\'^\\+/^`\n\'/`"\'\\`\t                                                Version : {%s}\n\n\t\t                                      \n\n ' % config.VERSION