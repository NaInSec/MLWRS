﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyDescription("")]
[assembly: AssemblyCompany("")]
[assembly: ComVisible(false)]
[assembly: AssemblyProduct("viconect")]
[assembly: Guid("9d8b7347-5028-489a-9311-631ad7653654")]
[assembly: AssemblyTitle("viconect")]
[assembly: CLSCompliant(true)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("Copyright ©  2010")]
[assembly: AssemblyVersion("1.0.0.0")]
